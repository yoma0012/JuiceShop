namespace JuiceShop.Models
{
    public enum MenuItem
    {
        MangoSlushie,
        StrawberrySmoothie,
        LemonTea,
        PineappleSlushie
    }
}
