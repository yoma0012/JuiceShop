using System;
using System.ComponentModel.DataAnnotations;

namespace JuiceShop.Models
{
    public class Order
    {
        private static int _nextId = 1;

        public Order()
        {
            Id = _nextId++;
            OrderDate = DateTime.Now;
        }

        public int Id { get; private set; }

        [Required, StringLength(50)]
        public string CustomerName { get; set; } = string.Empty;

        [Required]
        public MenuItem MenuItem { get; set; }

        [Required, Range(1, 10)]
        public int Quantity { get; set; }

        public DateTime OrderDate { get; private set; }

        public decimal PricePerUnit { get; set; }

        public decimal TotalPrice => Quantity * PricePerUnit;
    }
}
