using System.Collections.Generic;
using JuiceShop.Models;

namespace JuiceShop.Data
{
    public static class OrderRepository
    {
        private static List<Order> _orders = new();

        public static void AddOrder(Order order)
        {
            _orders.Add(order);
        }

        public static List<Order> GetAllOrders()
        {
            return _orders;
        }
    }
}
