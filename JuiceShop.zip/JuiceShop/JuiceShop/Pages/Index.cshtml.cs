using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using JuiceShop.Data;
using JuiceShop.Models;
using System.Collections.Generic;
using System.Linq;

namespace JuiceShop.Pages
{
    public class IndexModel : PageModel
    {
        public List<Order> Orders { get; set; } = new();
        public SelectList MenuItems { get; set; }
        public string SelectedFilter { get; set; }

        public void OnGet(string filter)
        {
            var allOrders = OrderRepository.GetAllOrders()
                .OrderByDescending(o => o.OrderDate)
                .ToList();

            if (!string.IsNullOrEmpty(filter) && Enum.TryParse(filter, out MenuItem selected))
            {
                allOrders = allOrders.Where(o => o.MenuItem == selected).ToList();
            }

            Orders = allOrders;
            MenuItems = new SelectList(Enum.GetNames(typeof(MenuItem)));
        }
    }
}
