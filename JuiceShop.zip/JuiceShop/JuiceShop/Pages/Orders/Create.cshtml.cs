using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using JuiceShop.Data;
using JuiceShop.Models;

namespace JuiceShop.Pages.Orders
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Order Order { get; set; }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            Order.PricePerUnit = Order.MenuItem switch
            {
                MenuItem.MangoSlushie => 4.50m,
                MenuItem.StrawberrySmoothie => 5.00m,
                MenuItem.LemonTea => 3.75m,
                MenuItem.PineappleSlushie => 4.75m,
                _ => 0m
            };

            OrderRepository.AddOrder(Order);
            return RedirectToPage("/Index");
        }
    }
}
